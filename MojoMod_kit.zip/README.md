# MojoLauncher mod kit

1. `git clone https://github.com/MojoLauncher/MojoLauncher && cd MojoLauncher`
2. `bash ../MojoMod/customize.sh "MyLauncher" "com.me.mylauncher"`  then `git diff` to check it.
3. **Preload call** – in LauncherActivity.onCreate add (after super.onCreate):
   `PreloadInstaller.install(this, new java.io.File(Tools.DIR_GAME_NEW));`
   (If `Tools.DIR_GAME_NEW` doesn't exist in your version, grep Tools.java for the game directory constant.)
4. **Default settings** – grep for the defaults in `LauncherPreferences.java` / `res/xml/pref_*.xml`
   (RAM = `PREF_RAM_ALLOCATION`, renderer = `PREF_RENDERER`, look for `android:defaultValue`) and set yours.
5. Build: `./gradlew :app_pojavlauncher:assembleDebug` → APK in app_pojavlauncher/build/outputs/apk/debug/
6. Easiest: put this whole folder in a new GitHub repo, open Actions > "Build custom launcher APK" > Run workflow, then download the APK artifact.
7. Keep LICENSE (LGPLv3) and the credits section; don't use Mojang/Minecraft branding in the name.
