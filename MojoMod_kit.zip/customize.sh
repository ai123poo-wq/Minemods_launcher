#!/usr/bin/env bash
# Run from the ROOT of your MojoLauncher clone:
#   git clone https://github.com/MojoLauncher/MojoLauncher && cd MojoLauncher
#   bash /path/to/MojoMod/customize.sh "MyLauncher" "com.me.mylauncher"
set -e
NAME="${1:?app name}"; APPID="${2:?new application id}"
MOD="$(cd "$(dirname "$0")" && pwd)"
APP=app_pojavlauncher

# 1) Rebrand: package/application id + visible name (verify with git diff)
sed -i "s/git\.artdeell\.mojo/${APPID}/g" $APP/build.gradle
grep -rl --include=strings.xml 'name="app_name"\|name="app_short_name"' $APP/src/main/res/values | \
  xargs -r sed -i -E "s#(name=\"app_(short_)?name\">)[^<]*#\1${NAME}#"
echo "Now replace icon: $APP/src/main/res/mipmap-*/ic_launcher*.png and edit res/values/colors.xml for theme colors"

# 2) Bundle the X-ray pack in assets
mkdir -p $APP/src/main/assets/preload
cp "$MOD/XRay_Pack_Java.zip" $APP/src/main/assets/preload/

# 3) Installer helper (you call it once from LauncherActivity.onCreate, see README)
JAVA_DIR=$(dirname "$(find $APP/src/main/java -name LauncherActivity.java | head -1)")
PKG=$(grep -m1 '^package' "$JAVA_DIR/LauncherActivity.java" | sed 's/package \(.*\);/\1/')
sed "s/__PKG__/${PKG}/" "$MOD/PreloadInstaller.java.txt" > "$JAVA_DIR/PreloadInstaller.java"
# 4) Mod browser (Modrinth + CurseForge) as its own screen + separate launcher icon
sed "s/__PKG__/${PKG}/" "$MOD/ModBrowserActivity.java.txt" > "$JAVA_DIR/ModBrowserActivity.java"
MANIFEST=$APP/src/main/AndroidManifest.xml
sed -i "s#</application>#    <activity android:name=\"${PKG}.ModBrowserActivity\" android:label=\"Mod Browser\" android:exported=\"true\" android:theme=\"@android:style/Theme.DeviceDefault\"><intent-filter><action android:name=\"android.intent.action.MAIN\"/><category android:name=\"android.intent.category.LAUNCHER\"/></intent-filter></activity>\n</application>#" "$MANIFEST"
echo "Done. Next: follow README steps for default settings, then ./gradlew :app_pojavlauncher:assembleDebug"
